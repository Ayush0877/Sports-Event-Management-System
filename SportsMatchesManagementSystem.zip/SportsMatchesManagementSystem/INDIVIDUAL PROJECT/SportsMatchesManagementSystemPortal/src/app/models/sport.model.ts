export class sport {
  constructor(
    public sportsId: number,
    public noOfPlayers: number,
    public sportsName: string,
    public sportsType: string,
  ) { }
}
