

export class player {
  constructor(
    public playerId: number,
    public playerName: string,
    public age: number,
    public contactNumber: number,
    public email: string,
    public gender: number,
    public sportsName: string
  ) { }
}
