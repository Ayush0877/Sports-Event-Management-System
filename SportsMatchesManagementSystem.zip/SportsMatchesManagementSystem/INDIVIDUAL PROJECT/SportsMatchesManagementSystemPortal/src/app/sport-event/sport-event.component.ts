import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sport-event',
  templateUrl: './sport-event.component.html',
  styleUrls: ['./sport-event.component.css']
})
export class SportEventComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
