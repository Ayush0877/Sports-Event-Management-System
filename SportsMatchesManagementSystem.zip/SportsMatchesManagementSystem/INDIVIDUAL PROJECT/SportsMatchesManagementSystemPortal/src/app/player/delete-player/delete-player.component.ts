import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-player',
  templateUrl: './delete-player.component.html',
  styleUrls: ['./delete-player.component.css']
})
export class DeletePlayerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  onDelete(playerId:any){
    
  }

}
